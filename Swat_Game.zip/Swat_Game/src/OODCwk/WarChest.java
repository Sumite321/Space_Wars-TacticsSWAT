/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OODCwk;

/**
 *
 * @author admin
 */
public interface WarChest {
    
    public int getValue(); // get the BitCoin Value
    
    public void setValue(int v); // set the initial value of BitCoin
    
    public void addValue(int v); // add value to the BitCoin
    
    public void deductValue(int v); // deduct the value of the BitCoin
    
    
    
    
    
}
